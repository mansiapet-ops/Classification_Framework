# Reusable AutoML Classification Framework

This project implements a configuration-driven AutoML framework for
tabular classification with mandatory explainability and governance.

## Features
- Config-only retraining
- Multiple classification algorithms
- Hyperparameter optimization (Optuna)
- SHAP & LIME explainability
- Fairness metrics
- MLflow experiment tracking
- FastAPI deployment

---

## Project Structure
See `ARCHITECTURE.md`

---

## How to Run

### 1️⃣ Install dependencies
```bash
pip install -r requirements.txt