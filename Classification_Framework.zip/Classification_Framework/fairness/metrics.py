"""
fairness/metrics.py
-------------------
Computes fairness metrics for trained classification models.

This module:
✅ Computes fairness metrics across protected attributes
✅ Supports standard fairness definitions
✅ Produces audit-ready fairness reports
❌ Does NOT alter model predictions
❌ Does NOT enforce fairness constraints automatically
"""

from typing import Dict, Any
import numpy as np
import pandas as pd


# -----------------------------
# Public API
# -----------------------------
def evaluate_fairness(
    model,
    X,
    y_true,
    fairness_config: Dict
) -> Dict[str, Any]:
    """
    Evaluate fairness metrics for a trained model.

    Parameters
    ----------
    model : trained model
        Champion model
    X : pd.DataFrame or array-like
        Test features (must include protected attributes)
    y_true : array-like
        True labels
    fairness_config : dict
        `fairness` section of config

    Returns
    -------
    fairness_report : dict
        Fairness metrics per protected attribute
    """

    protected_attributes = fairness_config.get("protected_attributes", [])
    metrics = fairness_config.get("metrics", [])

    if not protected_attributes:
        return {"status": "fairness_not_requested"}

    # Convert to DataFrame if needed
    if not isinstance(X, pd.DataFrame):
        raise ValueError(
            "Fairness evaluation requires feature data as a DataFrame "
            "with protected attribute columns."
        )

    y_pred = model.predict(X)

    fairness_report = {}

    for attribute in protected_attributes:
        if attribute not in X.columns:
            raise ValueError(
                f"Protected attribute '{attribute}' not found in feature data."
            )

        fairness_report[attribute] = _compute_attribute_fairness(
            X[attribute],
            y_true,
            y_pred,
            metrics
        )

    return fairness_report


# -----------------------------
# Attribute-Level Fairness
# -----------------------------
def _compute_attribute_fairness(
    protected_series: pd.Series,
    y_true,
    y_pred,
    metrics: list
) -> Dict[str, Any]:
    """
    Compute fairness metrics for a single protected attribute.
    """

    results = {}
    values = protected_series.unique()

    for metric in metrics:
        if metric == "statistical_parity":
            results["statistical_parity"] = _statistical_parity(
                protected_series, y_pred, values
            )

        elif metric == "equal_opportunity":
            results["equal_opportunity"] = _equal_opportunity(
                protected_series, y_true, y_pred, values
            )

        else:
            raise ValueError(f"Unsupported fairness metric '{metric}'")

    return results


# -----------------------------
# Fairness Metrics
# -----------------------------
def _statistical_parity(
    protected_series: pd.Series,
    y_pred,
    values
) -> Dict[str, float]:
    """
    Statistical Parity:
    P(Y=1 | A = a) across groups
    """

    parity = {}

    for val in values:
        mask = protected_series == val
        parity[str(val)] = float(np.mean(y_pred[mask] == 1))

    return parity


def _equal_opportunity(
    protected_series: pd.Series,
    y_true,
    y_pred,
    values
) -> Dict[str, float]:
    """
    Equal Opportunity:
    True Positive Rate across groups
    """

    tpr = {}

    for val in values:
        mask = (protected_series == val) & (y_true == 1)

        if mask.sum() == 0:
            tpr[str(val)] = None
        else:
            tpr[str(val)] = float(np.mean(y_pred[mask] == 1))

    return tpr
