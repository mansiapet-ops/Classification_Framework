"""
analysis/advisor.py
-------------------
LLM-assisted advisory module for recommending the appropriate level
of statistical analysis (univariate, bivariate, multivariate).

This module:
✅ Advises (does not decide) analysis strategy
✅ Can operate with or without an LLM
✅ Produces audit-ready recommendations
❌ Does NOT modify data
❌ Does NOT affect model training
"""

from typing import Dict, Any
import json


# =============================
# Public API
# =============================
def recommend_analysis(
    dataset_metadata: Dict[str, Any],
    feature_store: Dict[str, Any],
    llm_config: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    Recommend analysis type based on dataset characteristics.

    Parameters
    ----------
    dataset_metadata : dict
        Information like rows, columns, feature types
    feature_store : dict
        Output from features.store
    llm_config : dict, optional
        LLM configuration (provider, model, enabled flag)

    Returns
    -------
    dict with:
      - recommended_analysis
      - confidence
      - reasoning
      - llm_used
    """

    # If LLM is enabled, attempt LLM-based advisory
    if llm_config and llm_config.get("enabled", False):
        try:
            return _llm_advisory(
                dataset_metadata,
                feature_store,
                llm_config
            )
        except Exception:
            # Safe fallback
            return _rule_based_advisory(
                dataset_metadata,
                feature_store,
                llm_used=False
            )

    # Default: deterministic rule-based advisory
    return _rule_based_advisory(
        dataset_metadata,
        feature_store,
        llm_used=False
    )


# =============================
# Rule-Based Advisor (Safe Default)
# =============================
def _rule_based_advisory(
    dataset_metadata: Dict[str, Any],
    feature_store: Dict[str, Any],
    llm_used: bool
) -> Dict[str, Any]:
    """
    Deterministic advisory logic when no LLM is used.
    """

    num_features = feature_store["features"]["count"]
    num_rows = dataset_metadata.get("rows", 0)

    if num_features <= 3:
        recommendation = "univariate"
        confidence = "high"
        reason = (
            "Small number of features; distribution-level "
            "analysis is sufficient."
        )

    elif num_features <= 10:
        recommendation = "bivariate"
        confidence = "high"
        reason = (
            "Moderate number of features; feature-to-target "
            "and pairwise relationships are informative."
        )

    else:
        recommendation = "multivariate"
        confidence = "medium"
        reason = (
            "Larger feature set detected; interaction effects "
            "may be significant."
        )

    return {
        "recommended_analysis": recommendation,
        "confidence": confidence,
        "reasoning": reason,
        "llm_used": llm_used
    }


# =============================
# LLM-Based Advisor (Advisory Only)
# =============================
def _llm_advisory(
    dataset_metadata: Dict[str, Any],
    feature_store: Dict[str, Any],
    llm_config: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Use an LLM to recommend analysis strategy.

    NOTE:
    - This function MUST remain advisory only.
    - Output should always be human-reviewable.
    """

    # Build prompt
    prompt = _build_prompt(dataset_metadata, feature_store)

    # Example placeholder logic
    # (Replace with OpenAI / Azure / local LLM call if desired)
    # --------------------------------------------------------
    #
    # response = call_llm_api(
    #     model=llm_config["model"],
    #     prompt=prompt
    # )
    #
    # parsed = parse_llm_response(response)
    #
    # --------------------------------------------------------

    # Temporary deterministic mock response for safety
    parsed = {
        "recommended_analysis": "bivariate",
        "confidence": "high",
        "reasoning": (
            "Based on a moderate number of statistically validated "
            "features, analyzing feature-target relationships is sufficient "
            "before multivariate modeling."
        )
    }

    return {
        **parsed,
        "llm_used": True
    }


# =============================
# Prompt Construction
# =============================
def _build_prompt(
    dataset_metadata: Dict[str, Any],
    feature_store: Dict[str, Any]
) -> str:
    """
    Build a safe, bounded LLM prompt.
    """

    prompt = f"""
You are an ML data science advisor.
You are not allowed to suggest models or hyperparameters.

Dataset summary:
- Rows: {dataset_metadata.get("rows")}
- Columns: {dataset_metadata.get("columns")}
- Source: {dataset_metadata.get("source")}

Approved features ({feature_store["features"]["count"]}):
{json.dumps(feature_store["features"]["approved"], indent=2)}

Based only on this information, recommend ONE analysis type:
- univariate
- bivariate
- multivariate

Also provide a brief reasoning.
"""

    return prompt.strip()