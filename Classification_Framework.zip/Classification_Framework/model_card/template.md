# Model Card — [Model Name]

---

## 1. Model Overview
High-level description of the model, prediction task, and business objective.

---

## 2. Intended Use
Approved use cases for the model and explicitly prohibited or out-of-scope uses.

---

## 3. Training Data Description
Description of training data sources, time period covered, sampling strategy, and known data limitations.

---

## 4. Feature Summary
Overview of input features, feature types (numeric, categorical, text), and feature selection rationale.

---

## 5. Algorithms Considered
List of all algorithms evaluated during AutoML training.

---

## 6. Final Model Selection Rationale
Explanation of why the champion model was selected, including objective metric and comparison against alternatives.

---

## 7. Performance Metrics
Training, validation, and test performance metrics (AUC, F1, Precision, Recall, calibration if applicable).

---

## 8. Explainability Summary
Description of explainability techniques used (SHAP, LIME), with notes on global and local interpretability.

---

## 9. Fairness Analysis
Protected attributes evaluated, fairness metrics computed, and key observations or risks identified.

---

## 10. Limitations
Known weaknesses, edge cases, data gaps, and scenarios where model performance may degrade.

---

## 11. Assumptions
Key modeling and data assumptions made during development.

---

## 12. Ethical & Regulatory Considerations
Bias considerations, transparency measures, and regulatory alignment (e.g., SR 11‑7 principles).

---

## 13. Retraining Instructions
Guidelines for retraining the model, including triggers, data requirements, and configuration changes.

---

## 14. Version History
Model versioning information, training date, and change summary.
