"""
features/selection.py
----------------------
Performs statistically principled feature selection.

This module:
✅ Removes low-variance features
✅ Removes multicollinear features using correlation & VIF
✅ Flags heteroscedasticity risks (diagnostic only)
✅ Produces audit-ready selection reports
❌ Does NOT train models
❌ Does NOT mutate data
"""

from typing import Dict, List, Any
import pandas as pd
import numpy as np
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.diagnostic import het_breuschpagan
import statsmodels.api as sm


# =============================
# Main Entry Point
# =============================
def select_features(
    df: pd.DataFrame,
    numeric_features: List[str],
    target_col: str,
    variance_threshold: float = 0.01,
    corr_threshold: float = 0.9,
    vif_threshold: float = 5.0
) -> Dict[str, Any]:
    """
    Perform feature selection with statistical guarantees.

    Returns
    -------
    dict with:
      - selected_features
      - dropped_features
      - diagnostics
    """

    report = {
        "selected_features": [],
        "dropped_features": {
            "low_variance": [],
            "high_correlation": [],
            "high_vif": []
        },
        "diagnostics": {
            "heteroscedasticity": {}
        }
    }

    # -----------------------------
    # Step 1: Low Variance Filter
    # -----------------------------
    features_after_variance = []
    for feature in numeric_features:
        variance = df[feature].var()
        if variance < variance_threshold:
            report["dropped_features"]["low_variance"].append(feature)
        else:
            features_after_variance.append(feature)

    # -----------------------------
    # Step 2: Correlation Filter
    # -----------------------------
    corr_matrix = df[features_after_variance].corr().abs()
    upper_triangle = corr_matrix.where(
        np.triu(np.ones(corr_matrix.shape), k=1).astype(bool)
    )

    correlated_features = set()
    for col in upper_triangle.columns:
        if any(upper_triangle[col] > corr_threshold):
            correlated_features.add(col)

    report["dropped_features"]["high_correlation"] = list(correlated_features)

    features_after_corr = [
        f for f in features_after_variance if f not in correlated_features
    ]

    # -----------------------------
    # Step 3: VIF Filter
    # -----------------------------
    vif_df = pd.DataFrame()
    X = df[features_after_corr].dropna()
    X_const = sm.add_constant(X)

    vif_df["feature"] = X_const.columns
    vif_df["vif"] = [
        variance_inflation_factor(X_const.values, i)
        for i in range(X_const.shape[1])
    ]

    high_vif_features = vif_df[
        (vif_df["vif"] > vif_threshold) &
        (vif_df["feature"] != "const")
    ]["feature"].tolist()

    report["dropped_features"]["high_vif"] = high_vif_features

    final_features = [
        f for f in features_after_corr if f not in high_vif_features
    ]

    # -----------------------------
    # Step 4: Heteroscedasticity Diagnostics
    # -----------------------------
    for feature in final_features:
        try:
            X_bp = sm.add_constant(df[[feature]].dropna())
            y_bp = df.loc[X_bp.index, target_col]
            model = sm.OLS(y_bp, X_bp).fit()

            bp_test = het_breuschpagan(
                model.resid,
                model.model.exog
            )

            report["diagnostics"]["heteroscedasticity"][feature] = {
                "bp_stat": bp_test[0],
                "p_value": bp_test[1],
                "heteroscedastic": bp_test[1] < 0.05
            }
        except Exception:
            report["diagnostics"]["heteroscedasticity"][feature] = {
                "status": "test_failed"
            }

    report["selected_features"] = final_features

    return report