"""
features/store.py
-----------------
Lightweight Feature Store abstraction.

This module:
✅ Stores approved features in a versioned, auditable format
✅ Persists feature metadata & selection rationale
✅ Acts as the single source of truth for downstream modeling
❌ Does NOT perform feature engineering
❌ Does NOT modify datasets
"""

from typing import Dict, Any, List
import json
import os
from datetime import datetime


# =============================
# Constants
# =============================
FEATURE_STORE_DIR = "artifacts/feature_store"


# =============================
# Public API
# =============================
def create_feature_store(
    selected_features: List[str],
    hypothesis_report: Dict[str, Any],
    selection_report: Dict[str, Any],
    dataset_metadata: Dict[str, Any],
    version: int = None
) -> Dict[str, Any]:
    """
    Create a versioned feature store snapshot.

    Parameters
    ----------
    selected_features : list
        Final approved features after selection
    hypothesis_report : dict
        Output from features.hypothesis
    selection_report : dict
        Output from features.selection
    dataset_metadata : dict
        Dataset-level metadata (rows, cols, source, timestamp, etc.)
    version : int, optional
        Explicit version number. Auto-incremented if None.

    Returns
    -------
    feature_store : dict
        Feature store snapshot
    """

    os.makedirs(FEATURE_STORE_DIR, exist_ok=True)

    # Determine version
    if version is None:
        version = _get_next_version()

    feature_store = {
        "feature_store_version": f"v{version}",
        "created_at": datetime.utcnow().isoformat(),
        "dataset_metadata": dataset_metadata,
        "features": {
            "approved": selected_features,
            "count": len(selected_features)
        },
        "hypothesis_testing": hypothesis_report,
        "feature_selection": {
            "dropped_features": selection_report.get("dropped_features", {}),
            "diagnostics": selection_report.get("diagnostics", {})
        }
    }

    _persist_feature_store(feature_store, version)

    return feature_store


# =============================
# Internal Helpers
# =============================

def _sanitize_for_json(obj):
    """
    Recursively convert numpy and other non-JSON-safe
    objects into native Python types.
    """
    import numpy as np

    if isinstance(obj, dict):
        return {k: _sanitize_for_json(v) for k, v in obj.items()}

    if isinstance(obj, list):
        return [_sanitize_for_json(v) for v in obj]

    if isinstance(obj, tuple):
        return tuple(_sanitize_for_json(v) for v in obj)

    if isinstance(obj, (np.integer,)):
        return int(obj)

    if isinstance(obj, (np.floating,)):
        return float(obj)

    if isinstance(obj, (np.bool_,)):
        return bool(obj)

    return obj

def _get_next_version() -> int:
    """
    Determine the next feature store version.
    """
    if not os.path.exists(FEATURE_STORE_DIR):
        return 1

    existing_versions = []
    for file in os.listdir(FEATURE_STORE_DIR):
        if file.startswith("feature_store_v") and file.endswith(".json"):
            try:
                v = int(file.replace("feature_store_v", "").replace(".json", ""))
                existing_versions.append(v)
            except ValueError:
                continue

    return max(existing_versions, default=0) + 1


def _persist_feature_store(feature_store: Dict[str, Any], version: int) -> None:
    """
    Save feature store snapshot to disk.
    """
    file_path = os.path.join(
        FEATURE_STORE_DIR,
        f"feature_store_v{version}.json"
    )

    with open(file_path, "w") as f:
        json.dump(_sanitize_for_json(feature_store), f, indent=2)