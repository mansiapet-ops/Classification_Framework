"""
features/hypothesis.py
----------------------
Performs hypothesis testing to evaluate statistical significance
between features and the target variable.

This module:
✅ Runs appropriate statistical tests based on feature type
✅ Does NOT modify data
✅ Produces audit-ready hypothesis reports
✅ Is independent of modeling logic
"""

from typing import Dict, Any
import pandas as pd
import numpy as np
from scipy import stats


# =============================
# Main Entry Point
# =============================
def run_hypothesis_tests(
    df: pd.DataFrame,
    target_col: str,
    feature_config: Dict[str, list],
    alpha: float = 0.05
) -> Dict[str, Dict[str, Any]]:
    """
    Run hypothesis tests for each feature against the target.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe
    target_col : str
        Target column name
    feature_config : dict
        Dictionary with 'numeric' and 'categorical' feature lists
    alpha : float, optional
        Significance threshold (default 0.05)

    Returns
    -------
    report : dict
        Hypothesis testing results per feature
    """

    if target_col not in df.columns:
        raise ValueError(f"Target column '{target_col}' not found in dataframe")

    report = {}

    y = df[target_col]

    # Determine target type
    target_is_binary = _is_binary(y)
    target_is_numeric = pd.api.types.is_numeric_dtype(y)

    # -----------------------------
    # Numeric Feature Tests
    # -----------------------------
    for feature in feature_config.get("numeric", []):
        if feature not in df.columns:
            continue

        x = df[feature].dropna()
        y_aligned = y.loc[x.index]

        if target_is_binary:
            result = _t_test_binary_target(x, y_aligned, alpha)
        elif target_is_numeric:
            result = _pearson_test(x, y_aligned, alpha)
        else:
            continue

        report[feature] = result

    # -----------------------------
    # Categorical Feature Tests
    # -----------------------------
    for feature in feature_config.get("categorical", []):
        if feature not in df.columns:
            continue

        result = _chi_square_test(df[feature], y, alpha)
        report[feature] = result

    return report


# =============================
# Test Helpers
# =============================
def _is_binary(series: pd.Series) -> bool:
    """Check if a series is binary."""
    return series.dropna().nunique() == 2


def _t_test_binary_target(
    x: pd.Series,
    y: pd.Series,
    alpha: float
) -> Dict[str, Any]:
    """
    Independent two-sample t-test for numeric feature vs binary target.
    """
    class_0 = x[y == y.unique()[0]]
    class_1 = x[y == y.unique()[1]]

    stat, p_value = stats.ttest_ind(class_0, class_1, equal_var=False)

    return _format_result(
        test_name="Independent t-test",
        statistic=stat,
        p_value=p_value,
        alpha=alpha
    )


def _pearson_test(
    x: pd.Series,
    y: pd.Series,
    alpha: float
) -> Dict[str, Any]:
    """
    Pearson correlation test for numeric vs numeric.
    """
    corr, p_value = stats.pearsonr(x, y)

    return _format_result(
        test_name="Pearson correlation",
        statistic=corr,
        p_value=p_value,
        alpha=alpha,
        extra_info={"correlation_strength": abs(corr)}
    )


def _chi_square_test(
    x: pd.Series,
    y: pd.Series,
    alpha: float
) -> Dict[str, Any]:
    """
    Chi-square test for categorical feature vs target.
    """
    contingency_table = pd.crosstab(x, y)

    chi2, p_value, _, _ = stats.chi2_contingency(contingency_table)

    return _format_result(
        test_name="Chi-square test",
        statistic=chi2,
        p_value=p_value,
        alpha=alpha
    )


# =============================
# Formatting Helper
# =============================
def _format_result(
    test_name: str,
    statistic: float,
    p_value: float,
    alpha: float,
    extra_info: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    Standardized hypothesis result formatter.
    """
    significant = bool(p_value < alpha)

    result = {
        "test": test_name,
        "statistic": float(statistic),
        "p_value": float(p_value),
        "alpha": alpha,
        "significant": significant,
        "interpretation": (
            "Statistically significant relationship"
            if significant else
            "No statistically significant relationship"
        )
    }

    if extra_info:
        result.update(extra_info)

    return result