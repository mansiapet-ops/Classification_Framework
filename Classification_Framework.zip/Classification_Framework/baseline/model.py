"""
baseline/model.py
-----------------
Baseline model training with human-in-the-loop approval gating.

This module:
✅ Trains a simple, interpretable baseline model
✅ Computes standard classification metrics
✅ Enforces approval thresholds before AutoML
✅ Supports human override via config
❌ Does NOT tune hyperparameters
❌ Does NOT perform AutoML
"""

from typing import Dict, Any, Tuple
import numpy as np

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    roc_auc_score,
    f1_score,
    precision_score,
    recall_score
)


# =============================
# Public API
# =============================
def train_baseline_model(
    X_train,
    y_train,
    X_val,
    y_val,
    baseline_config: Dict[str, Any],
    objective_config: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Train and evaluate baseline model with approval logic.

    Returns
    -------
    dict with:
      - baseline_model
      - metrics
      - approved (bool)
      - reason
    """

    if not baseline_config.get("enabled", True):
        return {
            "baseline_model": None,
            "metrics": {},
            "approved": True,
            "reason": "Baseline disabled via config"
        }

    model_name = baseline_config.get("model", "logistic")

    model = _create_baseline_model(model_name)

    # -----------------------------
    # Train baseline
    # -----------------------------
    model.fit(X_train, y_train)

    # -----------------------------
    # Evaluate baseline
    # -----------------------------
    metrics = _evaluate_model(
        model,
        X_val,
        y_val,
        objective_config
    )

    # -----------------------------
    # Approval Gate
    # -----------------------------
    approval_result = _approval_check(
        metrics,
        baseline_config,
        objective_config
    )

    return {
        "baseline_model": model,
        "metrics": metrics,
        "approved": approval_result["approved"],
        "reason": approval_result["reason"]
    }


# =============================
# Model Factory
# =============================
def _create_baseline_model(model_name: str):
    """
    Create baseline model instance.
    """

    if model_name == "logistic":
        return LogisticRegression(
            max_iter=1000,
            solver="lbfgs"
        )

    if model_name == "decision_tree":
        return DecisionTreeClassifier(
            max_depth=5,
            random_state=42
        )

    raise ValueError(
        f"Unsupported baseline model '{model_name}'. "
        "Choose 'logistic' or 'decision_tree'."
    )


# =============================
# Evaluation
# =============================
def _evaluate_model(
    model,
    X,
    y_true,
    objective_config: Dict[str, Any]
) -> Dict[str, float]:
    """
    Compute baseline evaluation metrics.
    """

    y_pred = model.predict(X)

    metrics = {
        "f1": f1_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred)
    }

    if hasattr(model, "predict_proba"):
        y_proba = model.predict_proba(X)[:, 1]
        metrics["auc"] = roc_auc_score(y_true, y_proba)
    else:
        metrics["auc"] = None

    objective_metric = objective_config["metric"]
    metrics["objective_metric"] = metrics.get(objective_metric)

    return metrics


# =============================
# Approval Logic
# =============================
def _approval_check(
    metrics: Dict[str, float],
    baseline_config: Dict[str, Any],
    objective_config: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Determine whether AutoML can proceed.
    """

    min_required = baseline_config.get("min_auc_required", None)
    require_human = baseline_config.get("require_human_approval", False)

    objective_metric = objective_config["metric"]
    score = metrics.get(objective_metric)

    if min_required is not None and score is not None:
        if score < min_required:
            return {
                "approved": False,
                "reason": (
                    f"Baseline {objective_metric} "
                    f"{score:.3f} below required threshold {min_required}"
                )
            }

    if require_human:
        # Explicit human-in-the-loop gate
        return {
            "approved": baseline_config.get(
                "human_override", False
            ),
            "reason": (
                "Human approval required; "
                "set baseline.human_override=true to proceed"
            )
        }

    return {
        "approved": True,
        "reason": "Baseline performance acceptable"
    }