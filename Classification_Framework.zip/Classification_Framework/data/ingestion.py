"""
data/ingestion.py
-----------------
Responsible for ingesting raw tabular data from supported sources
(CSV, Parquet, SQL) based strictly on configuration.

This module:
✅ Loads raw data
✅ Infers schema metadata
❌ Does NOT modify data
❌ Does NOT perform preprocessing
❌ Does NOT drop or engineer features
"""

from typing import Tuple, Dict
import pandas as pd
from sqlalchemy import create_engine


# -----------------------------
# Main Ingestion Function
# -----------------------------
def ingest_data(data_config: Dict) -> Tuple[pd.DataFrame, Dict]:
    """
    Load raw data according to configuration.

    Parameters
    ----------
    data_config : dict
        Configuration under `data` section of YAML

    Returns
    -------
    df : pd.DataFrame
        Raw ingested dataframe
    schema_metadata : dict
        Inferred schema information for lineage/audit
    """

    source = data_config.get("source")
    path = data_config.get("path")

    if source is None or path is None:
        raise ValueError("Data source and path must be specified in config.data")

    if source == "csv":
        df = _load_csv(path)

    elif source == "parquet":
        df = _load_parquet(path)

    elif source == "sql":
        df = _load_sql(path)

    elif source == "excel":
        df = _load_excel(path)

    else:
        raise ValueError(
            f"Unsupported data source '{source}'. "
            f"Supported sources: csv, parquet, sql"
        )

    if df.empty:
        raise ValueError("Ingested dataset is empty")

    schema_metadata = _infer_schema(df)

    return df, schema_metadata


# -----------------------------
# Source Loaders
# -----------------------------
def _load_csv(path: str) -> pd.DataFrame:
    """Load CSV file."""
    try:
        return pd.read_csv(path)
    except Exception as e:
        raise RuntimeError(f"Failed to load CSV file: {e}")


def _load_parquet(path: str) -> pd.DataFrame:
    """Load Parquet file."""
    try:
        return pd.read_parquet(path)
    except Exception as e:
        raise RuntimeError(f"Failed to load Parquet file: {e}")


def _load_sql(connection_string: str) -> pd.DataFrame:
    """
    Load data from SQL using SQLAlchemy connection string.
    Assumes connection_string includes query or table reference.
    """
    try:
        engine = create_engine(connection_string)
        return pd.read_sql(connection_string, engine)
    except Exception as e:
        raise RuntimeError(f"Failed to load SQL data: {e}")

def _load_excel(path: str) -> pd.DataFrame:
    """Load Excel file."""
    try:
        return pd.read_excel(path)
    except Exception as e:
        raise RuntimeError(f"Failed to load Excel file: {e}")

# -----------------------------
# Schema Inference
# -----------------------------
def _infer_schema(df: pd.DataFrame) -> Dict:
    """
    Infer schema metadata for lineage and auditability.

    Returns:
    --------
    schema_metadata : dict
        Column names, dtypes, null ratios
    """

    schema_metadata = {
        "num_rows": df.shape[0],
        "num_columns": df.shape[1],
        "columns": {}
    }

    for column in df.columns:
        schema_metadata["columns"][column] = {
            "dtype": str(df[column].dtype),
            "null_ratio": df[column].isnull().mean()
        }

    return schema_metadata