"""
data/leakage.py
---------------
Detects potential target leakage in the dataset.

This module:
✅ Detects high correlation with target
✅ Flags ID-like columns
✅ Flags datetime leakage risks
❌ Does NOT modify data
❌ Does NOT auto-drop columns
"""

from typing import Dict, List
import pandas as pd
import numpy as np


# -----------------------------
# Main Leakage Detection Entry
# -----------------------------
def detect_leakage(
    df: pd.DataFrame,
    data_config: Dict,
    feature_config: Dict,
    correlation_threshold: float = 0.98
) -> None:
    """
    Detect potential target leakage.

    Raises error if severe leakage is detected.

    Parameters
    ----------
    df : pd.DataFrame
        Validated dataframe
    data_config : dict
        `data` section of config
    feature_config : dict
        `features` section of config
    correlation_threshold : float
        Threshold above which correlation is flagged
    """

    target = data_config.get("target")

    if target not in df.columns:
        raise ValueError("Target column missing during leakage detection")

    leakage_issues = []

    # ---- Check 1: Correlation Leakage ----
    corr_issues = _check_high_correlation(df, target, correlation_threshold)
    leakage_issues.extend(corr_issues)

    # ---- Check 2: ID-like Columns ----
    id_issues = _check_id_like_columns(df, feature_config)
    leakage_issues.extend(id_issues)

    # ---- Check 3: Datetime Leakage ----
    datetime_issues = _check_datetime_columns(df, feature_config)
    leakage_issues.extend(datetime_issues)

    if leakage_issues:
        message = (
            "Potential target leakage detected:\n"
            + "\n".join(f"- {issue}" for issue in leakage_issues)
        )
        raise ValueError(message)


# -----------------------------
# Leakage Heuristics
# -----------------------------
def _check_high_correlation(
    df: pd.DataFrame,
    target: str,
    threshold: float
) -> List[str]:
    """
    Detect features with extremely high correlation to target.
    """

    issues = []

    numeric_df = df.select_dtypes(include=[np.number])

    if target not in numeric_df.columns:
        return issues

    correlations = numeric_df.corr()[target].abs()

    for feature, corr_value in correlations.items():
        if feature == target:
            continue
        if corr_value >= threshold:
            issues.append(
                f"Feature '{feature}' has very high correlation ({corr_value:.2f}) "
                f"with target '{target}'"
            )

    return issues


def _check_id_like_columns(
    df: pd.DataFrame,
    feature_config: Dict
) -> List[str]:
    """
    Detect ID-like columns that may leak information.
    """
    issues = []

    candidate_columns = (
        feature_config.get("numeric", []) +
        feature_config.get("categorical", [])
    )

    for col in candidate_columns:
        if col not in df.columns:
            continue

        unique_ratio = df[col].nunique() / len(df)

        # Heuristic: IDs tend to have very high cardinality
        if unique_ratio > 0.95:
            issues.append(
                f"Column '{col}' looks like an ID (unique_ratio={unique_ratio:.2f}) "
                "and may cause leakage"
            )

    return issues


def _check_datetime_columns(
    df: pd.DataFrame,
    feature_config: Dict
) -> List[str]:
    """
    Detect datetime columns that may leak future information.
    """
    issues = []

    date_like_keywords = ["date", "time", "timestamp"]

    for col in df.columns:
        col_lower = col.lower()

        if any(keyword in col_lower for keyword in date_like_keywords):
            # If included as feature → flag
            if (
                col in feature_config.get("numeric", []) or
                col in feature_config.get("categorical", [])
            ):
                issues.append(
                    f"Datetime-like column '{col}' is used as a feature "
                    "and may leak temporal information"
                )

    return issues