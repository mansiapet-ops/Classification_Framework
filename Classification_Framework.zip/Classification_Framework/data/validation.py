"""
data/validation.py
------------------
Performs strict validation checks on raw ingested data.

This module:
✅ Validates presence of required columns
✅ Checks null ratios
✅ Detects duplicate rows
✅ Verifies target column existence
❌ Does NOT modify data
"""

from typing import Dict, List
import pandas as pd


# -----------------------------
# Main Validation Function
# -----------------------------
def validate_data(
    df: pd.DataFrame,
    data_config: Dict,
    feature_config: Dict
) -> pd.DataFrame:
    """
    Validate raw dataframe against config expectations.

    Parameters
    ----------
    df : pd.DataFrame
        Raw ingested dataframe
    data_config : dict
        `data` section of config
    feature_config : dict
        `features` section of config

    Returns
    -------
    df : pd.DataFrame
        Validated dataframe (unchanged)
    """

    _check_target_column(df, data_config)
    _check_feature_columns(df, feature_config)
    _check_null_ratios(df)
    _check_duplicates(df, data_config)

    return df


# -----------------------------
# Validation Checks
# -----------------------------
def _check_target_column(df: pd.DataFrame, data_config: Dict):
    """Ensure target column exists and is non-empty."""
    target = data_config.get("target")

    if target not in df.columns:
        raise ValueError(f"Target column '{target}' not found in dataset")

    if df[target].isnull().all():
        raise ValueError(f"Target column '{target}' contains only null values")


def _check_feature_columns(df: pd.DataFrame, feature_config: Dict):
    """Ensure all configured feature columns exist."""
    expected_columns = (
        feature_config.get("numeric", []) +
        feature_config.get("categorical", []) +
        feature_config.get("text", []) +
        feature_config.get("drop", [])
    )

    missing_columns = [
        col for col in expected_columns if col not in df.columns
    ]

    if missing_columns:
        raise ValueError(
            f"Configured feature columns missing from dataset: {missing_columns}"
        )


def _check_null_ratios(df: pd.DataFrame, max_null_ratio: float = 0.95):
    """
    Check for columns with excessive null values.

    Columns exceeding max_null_ratio are flagged as errors,
    as they provide little to no signal.
    """
    high_null_columns = [
        col for col in df.columns
        if df[col].isnull().mean() > max_null_ratio
    ]

    if high_null_columns:
        raise ValueError(
            f"Columns with excessive null values (> {max_null_ratio*100}%): "
            f"{high_null_columns}"
        )


def _check_duplicates(df: pd.DataFrame, data_config: Dict):
    """
    Detect duplicate rows using id_column if available,
    otherwise check full-row duplicates.
    """
    id_column = data_config.get("id_column")

    if id_column and id_column in df.columns:
        duplicate_count = df[id_column].duplicated().sum()
        if duplicate_count > 0:
            raise ValueError(
                f"Found {duplicate_count} duplicate rows based on id_column '{id_column}'"
            )
    else:
        duplicate_count = df.duplicated().sum()
        if duplicate_count > 0:
            raise ValueError(
                f"Found {duplicate_count} fully duplicated rows in dataset"
            )