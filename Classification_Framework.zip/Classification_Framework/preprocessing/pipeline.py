"""
preprocessing/pipeline.py
-------------------------
Builds and applies a shared preprocessing pipeline using sklearn.

This module:
✅ Builds ONE pipeline per run
✅ Fits ONLY on training data
✅ Applies consistently to train/val/test
✅ Produces serializable & invertible pipeline
❌ Does NOT include model-specific logic
"""

from typing import Dict, Tuple
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import (
    OneHotEncoder,
    StandardScaler
)
from sklearn.impute import SimpleImputer
from sklearn.feature_extraction.text import TfidfVectorizer


# -----------------------------
# Main Pipeline Entry Point
# -----------------------------
def build_and_apply_pipeline(
    df: pd.DataFrame,
    data_config: Dict,
    feature_config: Dict
) -> Tuple[Dict, Pipeline]:
    """
    Builds preprocessing pipeline and applies it to train/val/test splits.

    Parameters
    ----------
    df : pd.DataFrame
        Validated dataset
    data_config : dict
        `data` section of config
    feature_config : dict
        `features` section of config

    Returns
    -------
    datasets : dict
        {'train': (X_train, y_train),
         'val': (X_val, y_val),
         'test': (X_test, y_test)}
    pipeline : sklearn Pipeline
        Fitted preprocessing pipeline
    """

    target = data_config["target"]
    drop_cols = feature_config.get("drop", [])

    # Separate target
    y = df[target]
    X = df.drop(columns=[target] + drop_cols)

    # Train / Val / Test split
    X_train, X_temp, y_train, y_temp = train_test_split(
        X,
        y,
        test_size=(1 - data_config["split"]["train"]),
        stratify=y,
        random_state=42
    )

    val_ratio = data_config["split"]["val"] / (
        data_config["split"]["val"] + data_config["split"]["test"]
    )

    X_val, X_test, y_val, y_test = train_test_split(
        X_temp,
        y_temp,
        test_size=(1 - val_ratio),
        stratify=y_temp,
        random_state=42
    )

    # Build pipeline
    pipeline = _build_pipeline(feature_config)

    # Fit ONLY on training data
    X_train_transformed = pipeline.fit_transform(X_train)

    # Apply to validation and test
    X_val_transformed = pipeline.transform(X_val)
    X_test_transformed = pipeline.transform(X_test)

    datasets = {
        "train": (X_train_transformed, y_train),
        "val": (X_val_transformed, y_val),
        "test": (X_test_transformed, y_test)
    }

    return datasets, pipeline


# -----------------------------
# Pipeline Builder
# -----------------------------
def _build_pipeline(feature_config: Dict) -> Pipeline:
    """
    Construct sklearn preprocessing pipeline.
    """

    numeric_features = feature_config.get("numeric", [])
    categorical_features = feature_config.get("categorical", [])
    text_features = feature_config.get("text", [])

    transformers = []

    # ---- Numeric Pipeline ----
    if numeric_features:
        numeric_pipeline = Pipeline(steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler())
        ])

        transformers.append(
            ("numeric", numeric_pipeline, numeric_features)
        )

    # ---- Categorical Pipeline ----
    if categorical_features:
        categorical_pipeline = Pipeline(steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore", sparse=False))
        ])

        transformers.append(
            ("categorical", categorical_pipeline, categorical_features)
        )

    # ---- Text Pipeline ----
    for text_col in text_features:
        transformers.append(
            (
                f"text_{text_col}",
                TfidfVectorizer(
                    max_features=500,
                    ngram_range=(1, 2)
                ),
                text_col
            )
        )

    if not transformers:
        raise ValueError(
            "No features provided to preprocessing pipeline. "
            "Check config.features."
        )

    column_transformer = ColumnTransformer(
        transformers=transformers,
        remainder="drop"
    )

    pipeline = Pipeline(steps=[
        ("preprocessor", column_transformer)
    ])

    return pipeline