"""
preprocessing/inverse.py
------------------------
Utilities for mapping transformed feature space back to original
feature names for explainability and auditability.

This module:
✅ Extracts feature names from sklearn pipelines
✅ Supports numeric, categorical (OHE), and text features
✅ Enables SHAP and LIME reporting in original feature space
"""

from typing import List
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer


# -----------------------------
# Public API
# -----------------------------
def get_feature_names(pipeline: Pipeline) -> List[str]:
    """
    Retrieve human-readable feature names after preprocessing.

    Parameters
    ----------
    pipeline : sklearn Pipeline
        Fitted preprocessing pipeline

    Returns
    -------
    feature_names : list of str
        Expanded feature names corresponding to transformed features
    """

    if "preprocessor" not in pipeline.named_steps:
        raise ValueError(
            "Pipeline does not contain a 'preprocessor' step. "
            "Cannot extract feature names."
        )

    preprocessor = pipeline.named_steps["preprocessor"]

    if not isinstance(preprocessor, ColumnTransformer):
        raise ValueError(
            "Expected sklearn ColumnTransformer inside pipeline."
        )

    feature_names = []

    for name, transformer, columns in preprocessor.transformers_:
        if transformer == "drop":
            continue

        if hasattr(transformer, "get_feature_names_out"):
            # OneHotEncoder, TfidfVectorizer, etc.
            names = transformer.get_feature_names_out(columns)
            feature_names.extend(names)

        elif hasattr(transformer, "named_steps"):
            # Nested pipeline (numeric pipeline, categorical pipeline)
            final_step = list(transformer.named_steps.values())[-1]

            if hasattr(final_step, "get_feature_names_out"):
                names = final_step.get_feature_names_out(columns)
                feature_names.extend(names)
            else:
                feature_names.extend(columns)

        else:
            # Fallback: assume original column names
            if isinstance(columns, list):
                feature_names.extend(columns)
            else:
                feature_names.append(columns)

    return [str(f) for f in feature_names]