"""
main.py
-------
Single entry point for the AutoML Classification Framework.

Responsibilities:
- Load configuration
- Orchestrate end-to-end pipeline execution
- Enforce execution order
- Fail fast on contract violations

NO ML logic lives here.
"""

import argparse
from pydantic import config
import yaml
import sys
from pathlib import Path

# -----------------------------
# Module Imports (Strict Order)
# -----------------------------
from data.ingestion import ingest_data
from data.validation import validate_data
from data.leakage import detect_leakage

from features.store import create_feature_store
from preprocessing.pipeline import build_and_apply_pipeline

from models.registry import get_model_registry
from tuning.optuna_engine import run_hyperparameter_optimization

from evaluation.metrics import evaluate_models
from evaluation.statistics import select_champion
from evaluation.confusion import generate_confusion_matrix
from evaluation.calibration import generate_calibration_curve

from explainability.shap_engine import generate_shap_explanations
from fairness.metrics import evaluate_fairness

from registry.mlflow_logger import log_run_to_mlflow

from features.hypothesis import run_hypothesis_tests
from features.selection import select_features
from features.store import create_feature_store
from explainability.pdp import generate_partial_dependence_plots

# -----------------------------
# Configuration Loader
# -----------------------------
def load_config(config_path: str) -> dict:
    """Load YAML config file."""
    config_path = Path(config_path)

    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    return config


# -----------------------------
# Entry Point
# -----------------------------
def main(config_path: str):
    print(" Starting AutoML Classification Framework")
    print(f" Using config: {config_path}")

    # 1. Load Config
    config = load_config(config_path)

    # 2. Data Ingestion
    print(" Ingesting data...")
    df_raw, schema_metadata = ingest_data(config["data"])

    # 3. Data Validation
    print(" Validating data...")
    df_validated = validate_data(df_raw, config["data"], config["features"])

    # 4. Leakage Detection
    print(" Checking for target leakage...")
    detect_leakage(df_validated, config["data"], config["features"])

    
    hypothesis_report = run_hypothesis_tests(
        df=df_validated,
        target_col=config["data"]["target"],
        feature_config=config["features"]
    )
    
    
    selection_report = select_features(
        df=df_validated,
        numeric_features=config["features"]["numeric"],
        target_col=config["data"]["target"]
    )

    final_features = selection_report["selected_features"]



    feature_store = create_feature_store(
        selected_features=selection_report["selected_features"],
        hypothesis_report=hypothesis_report,
        selection_report=selection_report,
        dataset_metadata={
            "rows": df_validated.shape[0],
            "columns": df_validated.shape[1],
            "source": config["data"]["source"]
        }
    )

    # Override downstream features
    config["features"]["numeric"] = feature_store["features"]["approved"]

    # 5. Preprocessing Pipeline
    print("  Building preprocessing pipeline...")
    datasets, pipeline = build_and_apply_pipeline(
        df_validated,
        config["data"],
        config["features"]
    )

    X_train, y_train = datasets["train"]
    X_val, y_val = datasets["val"]
    X_test, y_test = datasets["test"]
    
    from analysis.advisor import recommend_analysis

    analysis_advice = recommend_analysis(
        dataset_metadata={
           "rows": df_validated.shape[0],
           "columns": df_validated.shape[1],
           "source": config["data"]["source"]
        },
        feature_store=feature_store,
        llm_config=config.get("llm_advisor", {})
    )

    print("Analysis recommendation:", analysis_advice)

    from baseline.model import train_baseline_model

    baseline_result = train_baseline_model(
        X_train, y_train,
        X_val, y_val,
        baseline_config=config["baseline"],
        objective_config=config["objective"]
    )

    if not baseline_result["approved"]:
        raise RuntimeError(
            f"AutoML blocked: {baseline_result['reason']}"
        )

    # 6. Model Registry
    print(" Initializing model registry...")
    model_registry = get_model_registry(config["algorithms"])

    # 7. Hyperparameter Optimization
    print("Running hyperparameter tuning...")
    tuned_models, tuning_history = run_hyperparameter_optimization(
        model_registry,
        X_train,
        y_train,
        X_val,
        y_val,
        config
    )

    # 8. Model Evaluation
    print(" Evaluating models...")
    evaluation_results = evaluate_models(
        tuned_models,
        X_test,
        y_test,
        config["objective"]
    )

    # 9. Champion Selection
    print(" Selecting champion model...")
    champion_model, champion_metrics = select_champion(
        evaluation_results,
        config["objective"],
        tuned_models
    )

    # Confusion Matrix Artifact
    confusion_matrix_path = generate_confusion_matrix(
        champion_model,
        X_test,
        y_test
    )

       
    # Calibration Curve Artifact
    calibration_curve_path = generate_calibration_curve(
        champion_model,
        X_test,
        y_test
    )


    # 10. Explainability (Mandatory)
    print(" Generating SHAP explanations...")
    shap_artifacts = generate_shap_explanations(
        champion_model,
        X_test,
        pipeline,
        config["constraints"]
    )

    
    # Partial Dependence Plots
    pdp_paths = generate_partial_dependence_plots(
        champion_model,
        X_train,
        feature_names=pipeline.get_feature_names_out().tolist(),
        top_k=3
    )


    # 11. Fairness Evaluation (Optional)
    print("  Evaluating fairness...")
    fairness_report = evaluate_fairness(
        champion_model,
        X_test,
        y_test,
        config.get("fairness", {})
    )

    # 12. MLflow Logging
    print(" Logging run to MLflow...")
    log_run_to_mlflow(
        config=config,
        schema=schema_metadata,
        pipeline=pipeline,
        model=champion_model,
        metrics=champion_metrics,
        shap_artifacts=shap_artifacts,
        fairness_report=fairness_report,
        tuning_history=tuning_history,
        
        extra_artifacts={
            "hypothesis_report": hypothesis_report,
            "selection_report": selection_report,
            "analysis_advice": analysis_advice,
            "baseline_metrics": baseline_result["metrics"],
            "confusion_matrix": confusion_matrix_path,
            "calibration_curve": calibration_curve_path,
            "pdp_plots": pdp_paths
        }
    )

    print(" AutoML pipeline completed successfully!")
    print(" Champion model registered and ready for deployment.")


# -----------------------------
# CLI Hook
# -----------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Reusable AutoML Classification Framework"
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to YAML configuration file"
    )

    args = parser.parse_args()

    try:
        main(args.config)
    except Exception as e:
        print(" Pipeline failed.")
        print(f"Error: {e}")
        sys.exit(1)
