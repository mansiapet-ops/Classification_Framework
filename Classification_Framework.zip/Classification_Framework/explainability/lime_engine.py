"""
explainability/lime_engine.py
-----------------------------
Provides LIME-based local explanations for individual predictions.

This module:
✅ Generates per-instance local explanations
✅ Is model-agnostic
✅ Uses human-readable feature names
❌ Does NOT replace SHAP (SHAP is mandatory)
"""

from typing import Any, Dict
import numpy as np

from lime.lime_tabular import LimeTabularExplainer
from preprocessing.inverse import get_feature_names


# -----------------------------
# Public API
# -----------------------------
def generate_lime_explanation(
    model,
    X_train,
    X_instance,
    pipeline
) -> Dict[str, Any]:
    """
    Generate a LIME explanation for a single instance.

    Parameters
    ----------
    model : trained model
        Champion trained model
    X_train : array-like
        Transformed training features (used as background data)
    X_instance : array-like
        Single transformed instance (shape: [1, n_features])
    pipeline : sklearn Pipeline
        Fitted preprocessing pipeline

    Returns
    -------
    explanation : dict
        Local feature contribution explanation
    """

    # Get feature names from preprocessing
    feature_names = get_feature_names(pipeline)

    if X_instance.ndim != 2 or X_instance.shape[0] != 1:
        raise ValueError(
            "X_instance must be a single sample with shape (1, n_features)"
        )

    # Initialize LIME explainer
    explainer = LimeTabularExplainer(
        training_data=np.array(X_train),
        feature_names=feature_names,
        class_names=["class_0", "class_1"],
        discretize_continuous=True,
        mode="classification"
    )

    # Generate explanation
    explanation = explainer.explain_instance(
        X_instance[0],
        model.predict_proba,
        num_features=min(10, X_train.shape[1])
    )

    # Format explanation output
    local_explanation = {
        "prediction_probability": model.predict_proba(X_instance)[0].tolist(),
        "local_feature_importance": explanation.as_list(),
    }

    return local_explanation
