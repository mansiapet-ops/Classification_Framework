"""
explainability/pdp.py
---------------------
Generates Partial Dependence Plots (PDP) for trained models.
"""

import os
import matplotlib.pyplot as plt
from sklearn.inspection import PartialDependenceDisplay


def generate_partial_dependence_plots(
    model,
    X_train,
    feature_names,
    top_k: int = 3,
    output_dir: str = "artifacts/explainability"
) -> list:
    """
    Generate PDP plots for top-k features.

    Parameters
    ----------
    model : trained model
    X_train : array-like
        Training data (used for PDP grid)
    feature_names : list
        Feature names after preprocessing
    top_k : int
        Number of features to generate PDPs for
    output_dir : str
        Directory to save PDP images

    Returns
    -------
    List of saved PDP image paths
    """

    os.makedirs(output_dir, exist_ok=True)

    # Use first top_k features (safe & deterministic)
    selected_features = list(range(min(top_k, X_train.shape[1])))

    pdp_paths = []

    for feature_index in selected_features:
        display = PartialDependenceDisplay.from_estimator(
            model,
            X_train,
            [feature_index],
            feature_names=feature_names,
            grid_resolution=50
        )

        plt.tight_layout()

        file_path = os.path.join(
            output_dir,
            f"pdp_feature_{feature_names[feature_index]}.png"
        )
        plt.savefig(file_path)
        plt.close()

        pdp_paths.append(file_path)

    return pdp_paths
