"""
explainability/shap_engine.py
-----------------------------
Generates SHAP-based explainability artifacts for trained models.

This module:
✅ Enforces mandatory SHAP explainability
✅ Supports tree-based and non-tree models
✅ Produces global and local feature explanations
✅ Integrates with preprocessing inverse mapping
❌ Does NOT modify model predictions
"""

from typing import Dict, Any
import numpy as np
import shap

from preprocessing.inverse import get_feature_names


# -----------------------------
# Public API
# -----------------------------
def generate_shap_explanations(
    model,
    X,
    pipeline,
    constraints: Dict
) -> Dict[str, Any]:
    """
    Generate SHAP explanations for a trained model.

    Parameters
    ----------
    model : trained model
        Champion trained model
    X : array-like
        Transformed test features
    pipeline : sklearn Pipeline
        Fitted preprocessing pipeline
    constraints : dict
        `constraints` section from config

    Returns
    -------
    shap_artifacts : dict
        SHAP values, expected value, and feature names
    """

    explainability_mode = constraints.get("explainability_mode", "full")

    # Get original feature names
    feature_names = get_feature_names(pipeline)

    # Select appropriate SHAP explainer
    explainer = _get_shap_explainer(model, X)

    if explainer is None:
        raise RuntimeError(
            "SHAP explainer could not be created. "
            "Explainability is mandatory — failing run."
        )

    # Compute SHAP values
    if explainability_mode == "fast":
        # Subsample for performance
        sample_size = min(200, X.shape[0])
        X_sample = X[:sample_size]
        shap_values = explainer.shap_values(X_sample)
    else:
        shap_values = explainer.shap_values(X)

    shap_artifacts = {
        "shap_values": shap_values,
        "expected_value": explainer.expected_value,
        "feature_names": feature_names,
        "explainer_type": explainer.__class__.__name__
    }

    return shap_artifacts


# -----------------------------
# Explainer Selection
# -----------------------------
def _get_shap_explainer(model, X):
    """
    Select appropriate SHAP explainer based on model type.
    """

    model_class = model.__class__.__name__.lower()

    # Tree-based models
    if any(
        tree_model in model_class
        for tree_model in ["tree", "forest", "xgb", "lgbm", "catboost"]
    ):
        try:
            return shap.TreeExplainer(model)
        except Exception as e:
            raise RuntimeError(f"TreeExplainer failed: {e}")

    # Linear models
    if "logistic" in model_class or "linear" in model_class:
        try:
            return shap.LinearExplainer(model, X, feature_perturbation="interventional")
        except Exception:
            pass

    # Fallback: KernelExplainer (model-agnostic)
    try:
        return shap.KernelExplainer(
            model.predict_proba,
            shap.sample(X, min(100, X.shape[0]))
        )
    except Exception as e:
        raise RuntimeError(f"KernelExplainer failed: {e}")