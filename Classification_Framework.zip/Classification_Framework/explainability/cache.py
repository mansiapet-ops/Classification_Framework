"""
explainability/cache.py
-----------------------
Caching utilities for storing and retrieving explainability artifacts
(SHAP, LIME) to avoid expensive recomputation.

This module:
✅ Caches explainability artifacts deterministically
✅ Is model- and data-aware
✅ Uses filesystem-based storage (cloud-agnostic)
❌ Does NOT compute explanations
"""

import os
import hashlib
import joblib
from typing import Any


# -----------------------------
# Cache Path Utilities
# -----------------------------
CACHE_DIR = "artifacts/explainability_cache"


def _ensure_cache_dir():
    """Ensure cache directory exists."""
    os.makedirs(CACHE_DIR, exist_ok=True)


# -----------------------------
# Cache Key Generation
# -----------------------------
def generate_cache_key(
    model,
    X,
    explainer_type: str
) -> str:
    """
    Generate a deterministic cache key based on:
    - model class
    - model parameters
    - data shape
    - explainer type
    """

    key_source = (
        f"{model.__class__.__name__}"
        f"{model.get_params()}"
        f"{X.shape}"
        f"{explainer_type}"
    )

    return hashlib.md5(key_source.encode("utf-8")).hexdigest()


# -----------------------------
# Cache Read/Write
# -----------------------------
def load_from_cache(cache_key: str) -> Any:
    """
    Load explainability artifact from cache if it exists.

    Returns
    -------
    cached_object or None
    """

    _ensure_cache_dir()
    path = os.path.join(CACHE_DIR, f"{cache_key}.joblib")

    if os.path.exists(path):
        return joblib.load(path)

    return None


def save_to_cache(cache_key: str, artifact: Any) -> None:
    """
    Save explainability artifact to cache.

    Parameters
    ----------
    cache_key : str
        Deterministic key
    artifact : Any
        Explainability artifact (SHAP values, etc.)
    """

    _ensure_cache_dir()
    path = os.path.join(CACHE_DIR, f"{cache_key}.joblib")

    joblib.dump(artifact, path)