"""
tuning/optuna_engine.py
----------------------
Runs hyperparameter optimization using Optuna for all enabled models.

This module:
✅ Orchestrates Optuna studies
✅ Enforces time & trial limits
✅ Trains and evaluates models
✅ Returns tuned model instances
❌ Does NOT perform final evaluation
❌ Does NOT log experiments
"""

from typing import Dict, Tuple
import time
import optuna
import numpy as np

from sklearn.base import clone
from sklearn.metrics import roc_auc_score, f1_score

from models.spaces import get_search_space


# -----------------------------
# Public API
# -----------------------------
def run_hyperparameter_optimization(
    model_registry: Dict[str, object],
    X_train,
    y_train,
    X_val,
    y_val,
    config: Dict
) -> Tuple[Dict[str, object], Dict]:
    """
    Run hyperparameter tuning for all enabled models.

    Parameters
    ----------
    model_registry : dict
        Mapping of algorithm_name -> base model
    X_train, y_train : array-like
        Training data
    X_val, y_val : array-like
        Validation data
    config : dict
        Full config dictionary

    Returns
    -------
    tuned_models : dict
        Mapping of algorithm_name -> best trained model
    tuning_history : dict
        Per-algorithm Optuna study summaries
    """

    constraints = config["constraints"]
    objective_cfg = config["objective"]

    max_trials = constraints["max_trials"]
    max_runtime_minutes = constraints["max_runtime_minutes"]
    direction = objective_cfg["direction"]

    tuned_models = {}
    tuning_history = {}

    for algo_name, base_model in model_registry.items():
        print(f"🔧 Tuning model: {algo_name}")

        start_time = time.time()

        study = optuna.create_study(direction=direction)

        study.optimize(
            lambda trial: _objective(
                trial,
                algo_name,
                base_model,
                X_train,
                y_train,
                X_val,
                y_val,
                objective_cfg["metric"]
            ),
            n_trials=max_trials,
            timeout=max_runtime_minutes * 60
        )

        # Clone base model and apply best params
        best_model = clone(base_model)
        best_model.set_params(**study.best_params)
        best_model.fit(X_train, y_train)

        tuned_models[algo_name] = best_model

        tuning_history[algo_name] = {
            "best_score": study.best_value,
            "best_params": study.best_params,
            "num_trials": len(study.trials),
            "duration_seconds": time.time() - start_time
        }

    return tuned_models, tuning_history


# -----------------------------
# Optuna Objective Function
# -----------------------------
def _objective(
    trial: optuna.trial.Trial,
    algo_name: str,
    base_model,
    X_train,
    y_train,
    X_val,
    y_val,
    metric_name: str
) -> float:
    """
    Optuna objective function for a single trial.
    """

    # Get hyperparameters for this algorithm
    params = get_search_space(trial, algo_name)

    # Create fresh model instance
    model = clone(base_model)
    model.set_params(**params)

    # Train
    model.fit(X_train, y_train)

    # Predict
    if metric_name == "auc":
        y_proba = model.predict_proba(X_val)[:, 1]
        score = roc_auc_score(y_val, y_proba)

    elif metric_name == "f1":
        y_pred = model.predict(X_val)
        score = f1_score(y_val, y_pred)

    else:
        raise ValueError(
            f"Unsupported optimization metric '{metric_name}'"
        )

    return score
