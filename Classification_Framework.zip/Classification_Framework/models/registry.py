"""
models/registry.py
------------------
Defines and instantiates supported classification algorithms.

This module:
✅ Maintains a strict algorithm whitelist
✅ Maps config names to model constructors
✅ Returns untrained model instances
❌ Does NOT perform tuning or training
"""

from typing import Dict

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier

# Optional gradient boosting libraries
try:
    from xgboost import XGBClassifier
except ImportError:
    XGBClassifier = None

try:
    from lightgbm import LGBMClassifier
except ImportError:
    LGBMClassifier = None

try:
    from catboost import CatBoostClassifier
except ImportError:
    CatBoostClassifier = None


# -----------------------------
# Algorithm Factory
# -----------------------------
def get_model_registry(algorithm_config: Dict) -> Dict[str, object]:
    """
    Instantiate base models based on config.

    Parameters
    ----------
    algorithm_config : dict
        `algorithms` section from config

    Returns
    -------
    model_registry : dict
        Mapping of algorithm_name -> untrained model instance
    """

    enabled_algorithms = algorithm_config.get("enable", [])

    model_registry = {}

    for algo_name in enabled_algorithms:
        model = _create_model(algo_name)
        model_registry[algo_name] = model

    if not model_registry:
        raise ValueError(
            "No valid algorithms enabled. "
            "Check config.algorithms.enable."
        )

    return model_registry


# -----------------------------
# Internal Model Creator
# -----------------------------
def _create_model(algo_name: str):
    """
    Create an untrained model instance by algorithm name.
    """

    if algo_name == "logistic":
        return LogisticRegression(
            max_iter=1000,
            solver="lbfgs"
        )

    if algo_name == "decision_tree":
        return DecisionTreeClassifier(
            random_state=42
        )

    if algo_name == "random_forest":
        return RandomForestClassifier(
            n_estimators=100,
            random_state=42,
            n_jobs=-1
        )

    if algo_name == "svm":
        return SVC(
            probability=True,
            kernel="rbf"
        )

    if algo_name == "mlp":
        return MLPClassifier(
            max_iter=300,
            random_state=42
        )

    if algo_name == "xgboost":
        if XGBClassifier is None:
            raise ImportError("xgboost is not installed")
        return XGBClassifier(
            eval_metric="logloss",
            use_label_encoder=False,
            random_state=42
        )

    if algo_name == "lightgbm":
        if LGBMClassifier is None:
            raise ImportError("lightgbm is not installed")
        return LGBMClassifier(
            random_state=42
        )

    if algo_name == "catboost":
        if CatBoostClassifier is None:
            raise ImportError("catboost is not installed")
        return CatBoostClassifier(
            verbose=False,
            random_state=42
        )

    raise ValueError(
        f"Unsupported algorithm '{algo_name}'. "
        "Must be one of: logistic, decision_tree, random_forest, "
        "svm, mlp, xgboost, lightgbm, catboost"
    )