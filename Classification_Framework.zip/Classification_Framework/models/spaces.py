"""
models/spaces.py
----------------
Defines Optuna-compatible hyperparameter search spaces
for each supported classification algorithm.

This module:
✅ Centralizes hyperparameter definitions
✅ Enforces bounded, safe search spaces
✅ Keeps tuning logic decoupled from models
"""

from typing import Dict
import optuna


# -----------------------------
# Public API
# -----------------------------
def get_search_space(trial: optuna.trial.Trial, algo_name: str) -> Dict:
    """
    Return hyperparameter search space for a given algorithm.

    Parameters
    ----------
    trial : optuna.trial.Trial
        Active Optuna trial
    algo_name : str
        Algorithm name from registry

    Returns
    -------
    params : dict
        Hyperparameters for model initialization
    """

    if algo_name == "logistic":
        return {
            "C": trial.suggest_loguniform("C", 1e-4, 10.0),
            "penalty": "l2",
            "solver": "lbfgs"
        }

    if algo_name == "decision_tree":
        return {
            "max_depth": trial.suggest_int("max_depth", 2, 20),
            "min_samples_split": trial.suggest_int("min_samples_split", 2, 20),
            "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 10)
        }

    if algo_name == "random_forest":
        return {
            "n_estimators": trial.suggest_int("n_estimators", 100, 500),
            "max_depth": trial.suggest_int("max_depth", 3, 20),
            "min_samples_split": trial.suggest_int("min_samples_split", 2, 20),
            "n_jobs": -1
        }

    if algo_name == "svm":
        return {
            "C": trial.suggest_loguniform("C", 1e-3, 100),
            "kernel": trial.suggest_categorical("kernel", ["rbf", "linear"]),
            "gamma": trial.suggest_categorical("gamma", ["scale", "auto"]),
            "probability": True
        }

    if algo_name == "mlp":
        return {
            "hidden_layer_sizes": trial.suggest_categorical(
                "hidden_layer_sizes",
                [(64,), (128,), (64, 32), (128, 64)]
            ),
            "alpha": trial.suggest_loguniform("alpha", 1e-5, 1e-2),
            "learning_rate_init": trial.suggest_loguniform(
                "learning_rate_init", 1e-4, 1e-2
            ),
            "max_iter": 300
        }

    if algo_name == "xgboost":
        return {
            "max_depth": trial.suggest_int("max_depth", 3, 10),
            "learning_rate": trial.suggest_loguniform("learning_rate", 0.01, 0.3),
            "n_estimators": trial.suggest_int("n_estimators", 100, 500),
            "subsample": trial.suggest_float("subsample", 0.6, 1.0),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0)
        }

    if algo_name == "lightgbm":
        return {
            "num_leaves": trial.suggest_int("num_leaves", 20, 150),
            "max_depth": trial.suggest_int("max_depth", -1, 20),
            "learning_rate": trial.suggest_loguniform("learning_rate", 0.01, 0.3),
            "n_estimators": trial.suggest_int("n_estimators", 100, 500)
        }

    if algo_name == "catboost":
        return {
            "depth": trial.suggest_int("depth", 4, 10),
            "learning_rate": trial.suggest_loguniform("learning_rate", 0.01, 0.3),
            "iterations": trial.suggest_int("iterations", 200, 600),
            "l2_leaf_reg": trial.suggest_loguniform("l2_leaf_reg", 1e-3, 10.0)
        }

    raise ValueError(
        f"No hyperparameter space defined for algorithm '{algo_name}'"
    )