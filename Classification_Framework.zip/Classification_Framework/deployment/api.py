"""
deployment/api.py
-----------------
FastAPI application for serving predictions and explanations
from the trained AutoML framework.

This module:
✅ Loads preprocessing pipeline and champion model
✅ Exposes prediction and explainability endpoints
✅ Enforces input validation via Pydantic schemas
❌ Does NOT perform training
❌ Does NOT alter model behavior
"""

from typing import List
import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException

from deployment.schema import (
    PredictionInput,
    BatchPredictionInput,
    PredictionOutput,
    BatchPredictionOutput,
    ExplainabilityOutput
)

from explainability.shap_engine import generate_shap_explanations
from explainability.lime_engine import generate_lime_explanation


# -----------------------------
# App Initialization
# -----------------------------
app = FastAPI(
    title="Reusable AutoML Classification API",
    description="Prediction and Explainability API",
    version="1.0.0"
)


# -----------------------------
# Load Artifacts (ON STARTUP)
# -----------------------------
try:
    PIPELINE = joblib.load("artifacts/preprocessing_pipeline.joblib")
    MODEL = joblib.load("artifacts/champion_model.joblib")
except Exception as e:
    raise RuntimeError(
        "Failed to load model or preprocessing pipeline. "
        "Ensure artifacts exist before starting API."
    ) from e


# -----------------------------
# Health Check
# -----------------------------
@app.get("/health")
def health_check():
    return {"status": "ok"}


# -----------------------------
# Prediction Endpoints
# -----------------------------
@app.post("/predict", response_model=PredictionOutput)
def predict(input_data: PredictionInput):
    """
    Perform prediction for a single input record.
    """

    try:
        df = pd.DataFrame([input_data.features])
        X_transformed = PIPELINE.transform(df)

        prediction = int(MODEL.predict(X_transformed)[0])
        probability = None

        if hasattr(MODEL, "predict_proba"):
            probability = float(MODEL.predict_proba(X_transformed)[0][1])

        return PredictionOutput(
            prediction=prediction,
            probability=probability
        )

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/predict/batch", response_model=BatchPredictionOutput)
def predict_batch(batch_input: BatchPredictionInput):
    """
    Perform batch prediction.
    """

    try:
        records = [record.features for record in batch_input.records]
        df = pd.DataFrame(records)
        X_transformed = PIPELINE.transform(df)

        preds = MODEL.predict(X_transformed)
        probs = None

        if hasattr(MODEL, "predict_proba"):
            probs = MODEL.predict_proba(X_transformed)[:, 1]

        outputs = []
        for i, pred in enumerate(preds):
            outputs.append(
                PredictionOutput(
                    prediction=int(pred),
                    probability=float(probs[i]) if probs is not None else None
                )
            )

        return BatchPredictionOutput(predictions=outputs)

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# -----------------------------
# Explainability Endpoints
# -----------------------------
@app.post("/explain", response_model=ExplainabilityOutput)
def explain(input_data: PredictionInput):
    """
    Generate SHAP (global) and LIME (local) explanations
    for a single prediction.
    """

    try:
        df = pd.DataFrame([input_data.features])
        X_transformed = PIPELINE.transform(df)

        # SHAP (global explanation based on training assumptions)
        shap_artifacts = generate_shap_explanations(
            MODEL,
            X_transformed,
            PIPELINE,
            constraints={"explainability_mode": "full"}
        )

        # LIME (local explanation)
        lime_artifact = generate_lime_explanation(
            MODEL,
            X_train=X_transformed,
            X_instance=X_transformed,
            pipeline=PIPELINE
        )

        return ExplainabilityOutput(
            global_explanations=dict(zip(
                shap_artifacts["feature_names"],
                np.mean(np.abs(shap_artifacts["shap_values"]), axis=0).tolist()
            )),
            local_explanations=lime_artifact["local_feature_importance"]
        )

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
