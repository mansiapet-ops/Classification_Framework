"""
deployment/schema.py
--------------------
Defines request and response schemas for model deployment API
using Pydantic.

This module:
✅ Enforces input schema validation
✅ Supports single and batch predictions
✅ Guarantees train–serve feature parity
❌ Does NOT perform inference
❌ Does NOT load models
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


# -----------------------------
# Input Schemas
# -----------------------------
class PredictionInput(BaseModel):
    """
    Schema for a single prediction input.

    Each field corresponds to a raw feature
    used during training (before preprocessing).
    """

    features: Dict[str, Any] = Field(
        ...,
        description="Raw feature dictionary matching training schema"
    )


class BatchPredictionInput(BaseModel):
    """
    Schema for batch prediction input.
    """

    records: List[PredictionInput] = Field(
        ...,
        min_items=1,
        description="List of prediction records"
    )


# -----------------------------
# Output Schemas
# -----------------------------
class PredictionOutput(BaseModel):
    """
    Schema for a single prediction output.
    """

    prediction: int = Field(
        ...,
        description="Predicted class label"
    )

    probability: Optional[float] = Field(
        None,
        description="Prediction probability for positive class"
    )


class BatchPredictionOutput(BaseModel):
    """
    Schema for batch prediction output.
    """

    predictions: List[PredictionOutput]


# -----------------------------
# Explainability Schemas
# -----------------------------
class ExplainabilityOutput(BaseModel):
    """
    Schema for explainability response.
    """

    global_explanations: Optional[Dict[str, float]] = Field(
        None,
        description="Global feature importance scores"
    )

    local_explanations: Optional[List] = Field(
        None,
        description="Local explanation for specific prediction(s)"
    )
