"""
evaluation/confusion.py
-----------------------
Generates and saves confusion matrix artifact for classification models.
"""

import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix


def generate_confusion_matrix(
    model,
    X_test,
    y_test,
    output_dir: str = "artifacts/evaluation"
) -> str:
    """
    Generate and save a confusion matrix plot.

    Returns
    -------
    Path to saved confusion matrix image
    """

    os.makedirs(output_dir, exist_ok=True)

    y_pred = model.predict(X_test)
    cm = confusion_matrix(y_test, y_pred)

    plt.figure(figsize=(6, 4))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        cbar=False
    )
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.title("Confusion Matrix")

    file_path = os.path.join(output_dir, "confusion_matrix.png")
    plt.tight_layout()
    plt.savefig(file_path)
    plt.close()

    return file_path