"""
evaluation/statistics.py
------------------------
Provides statistical comparison utilities and champion model selection.

This module:
✅ Selects a champion model based on objective metric
✅ Supports statistical significance testing (McNemar's test)
❌ Does NOT compute base metrics (handled in metrics.py)
"""

from typing import Dict, Tuple
import numpy as np

from statsmodels.stats.contingency_tables import mcnemar


# -----------------------------
# Champion Selection
# -----------------------------
def select_champion(
    evaluation_results,
    objective_config,
    trained_models
):
    """
    Select the champion model based on objective metric.

    Returns:
    --------
    champion_model : trained model object
    champion_metrics : dict
    """

    objective_metric = objective_config["metric"]
    direction = objective_config.get("direction", "maximize")

    scores = {
        model_name: metrics.get(objective_metric)
        for model_name, metrics in evaluation_results.items()
        if metrics.get(objective_metric) is not None
    }

    if direction == "maximize":
        champion_name = max(scores, key=scores.get)
    else:
        champion_name = min(scores, key=scores.get)

    champion_model = trained_models[champion_name]
    champion_metrics = evaluation_results[champion_name]

    return champion_model, champion_metrics

# -----------------------------
# Statistical Significance Test
# -----------------------------
def mcnemar_test(
    y_true,
    y_pred_model_a,
    y_pred_model_b,
    alpha: float = 0.05
) -> Dict:
    """
    Perform McNemar's test between two classifiers.

    Parameters
    ----------
    y_true : array-like
        True labels
    y_pred_model_a : array-like
        Predictions from model A
    y_pred_model_b : array-like
        Predictions from model B
    alpha : float
        Significance level

    Returns
    -------
    result : dict
        McNemar test statistic, p-value, and significance flag
    """

    # Build contingency table
    both_correct = np.sum(
        (y_pred_model_a == y_true) & (y_pred_model_b == y_true)
    )
    a_correct_b_wrong = np.sum(
        (y_pred_model_a == y_true) & (y_pred_model_b != y_true)
    )
    a_wrong_b_correct = np.sum(
        (y_pred_model_a != y_true) & (y_pred_model_b == y_true)
    )
    both_wrong = np.sum(
        (y_pred_model_a != y_true) & (y_pred_model_b != y_true)
    )

    table = [
        [both_correct, a_correct_b_wrong],
        [a_wrong_b_correct, both_wrong]
    ]

    test_result = mcnemar(table, exact=False, correction=True)

    return {
        "statistic": test_result.statistic,
        "p_value": test_result.pvalue,
        "significant": test_result.pvalue < alpha
    }