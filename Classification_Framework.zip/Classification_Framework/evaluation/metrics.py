"""
evaluation/metrics.py
---------------------
Computes evaluation metrics for trained classification models.

This module:
✅ Computes standard classification metrics
✅ Supports binary and multiclass metrics (extensible)
✅ Produces consistent metric dictionaries
❌ Does NOT select champion model
❌ Does NOT perform statistical testing
"""

from typing import Dict
import numpy as np

from sklearn.metrics import (
    roc_auc_score,
    f1_score,
    precision_score,
    recall_score
)


# -----------------------------
# Public API
# -----------------------------
def evaluate_models(
    trained_models: Dict[str, object],
    X_test,
    y_test,
    objective_config: Dict
) -> Dict[str, Dict]:
    """
    Evaluate trained models on test data.

    Parameters
    ----------
    trained_models : dict
        Mapping {model_name: trained_model}
    X_test : array-like
        Test features (preprocessed)
    y_test : array-like
        True labels
    objective_config : dict
        `objective` section of config

    Returns
    -------
    evaluation_results : dict
        Per-model evaluation metrics
    """

    evaluation_results = {}

    for model_name, model in trained_models.items():
        metrics = _compute_metrics(
            model,
            X_test,
            y_test,
            objective_config
        )

        evaluation_results[model_name] = metrics

    return evaluation_results


# -----------------------------
# Metric Computation
# -----------------------------
def _compute_metrics(
    model,
    X,
    y_true,
    objective_config: Dict
) -> Dict:
    """
    Compute classification metrics for a single model.
    """

    metrics = {}

    # Predictions
    y_pred = model.predict(X)

    if hasattr(model, "predict_proba"):
        y_proba = model.predict_proba(X)[:, 1]
    else:
        y_proba = None

    # --- Core Metrics ---
    if y_proba is not None:
        metrics["auc"] = roc_auc_score(y_true, y_proba)
    else:
        metrics["auc"] = None

    metrics["f1"] = f1_score(y_true, y_pred)
    metrics["precision"] = precision_score(y_true, y_pred)
    metrics["recall"] = recall_score(y_true, y_pred)

    # --- Objective Metric (explicit) ---
    objective_metric = objective_config["metric"]
    metrics["objective_metric"] = metrics.get(objective_metric)

    return metrics