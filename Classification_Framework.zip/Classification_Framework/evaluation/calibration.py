"""
evaluation/calibration.py
-------------------------
Generates and saves calibration curve (reliability diagram)
for classification models.
"""

import os
import matplotlib.pyplot as plt
import numpy as np
from sklearn.calibration import calibration_curve


def generate_calibration_curve(
    model,
    X_test,
    y_test,
    n_bins: int = 10,
    output_dir: str = "artifacts/evaluation"
) -> str:
    """
    Generate and save a calibration curve for a classifier.

    Returns
    -------
    Path to saved calibration curve image
    """

    if not hasattr(model, "predict_proba"):
        raise ValueError("Model does not support probability prediction")

    os.makedirs(output_dir, exist_ok=True)

    # Get predicted probabilities for positive class
    y_prob = model.predict_proba(X_test)[:, 1]

    # Compute calibration curve
    frac_pos, mean_pred = calibration_curve(
        y_test,
        y_prob,
        n_bins=n_bins,
        strategy="uniform"
    )

    # Plot
    plt.figure(figsize=(6, 4))
    plt.plot(mean_pred, frac_pos, marker="o", label="Model")
    plt.plot([0, 1], [0, 1], linestyle="--", label="Perfectly calibrated")
    plt.xlabel("Mean predicted probability")
    plt.ylabel("Fraction of positives")
    plt.title("Calibration Curve (Reliability Diagram)")
    plt.legend()
    plt.grid(True)

    file_path = os.path.join(output_dir, "calibration_curve.png")
    plt.tight_layout()
    plt.savefig(file_path)
    plt.close()

    return file_path
