"""
registry/mlflow_logger.py
-------------------------
Centralized MLflow logging utility.

This module:
✅ Logs models, pipelines, metrics, and parameters
✅ Persists governance & analysis artifacts (JSON + files)
✅ Supports extensible artifact logging
✅ Remains pure (no ML logic)
"""

from typing import Dict, Any, Optional
import os
import json
import tempfile

import mlflow
import mlflow.sklearn


# =============================
# Public API
# =============================
def log_run_to_mlflow(
    config: Dict[str, Any],
    schema: Dict[str, Any],
    pipeline,
    model,
    metrics: Dict[str, float],
    shap_artifacts: Dict[str, Any],
    fairness_report: Dict[str, Any],
    tuning_history: Dict[str, Any],
    extra_artifacts: Optional[Dict[str, Any]] = None
) -> None:
    """
    Log a complete AutoML run to MLflow.

    extra_artifacts may contain:
    - dicts (logged as JSON)
    - file paths (logged as artifacts, e.g. PNGs)
    """

    mlflow.set_tracking_uri("sqlite:///mlflow.db")
    mlflow.set_experiment("Reusable_AutoML_Classification")

    with mlflow.start_run():

        # -------------------------
        # Log Config as Parameters
        # -------------------------
        _log_config_params(config)

        # -------------------------
        # Log Core Metrics
        # -------------------------
        for name, value in metrics.items():
            if value is not None:
                mlflow.log_metric(name, float(value))

        # -------------------------
        # Log Schema & Core Artifacts
        # -------------------------
        _log_json_artifact(schema, "data_schema.json")
        _log_json_artifact(tuning_history, "tuning_history.json")
        _log_json_artifact(fairness_report, "fairness_report.json")

        # -------------------------
        # Log Explainability Metadata
        # -------------------------
        shap_metadata = {
            "explainer_type": shap_artifacts.get("explainer_type"),
            "feature_names": shap_artifacts.get("feature_names")
        }
        _log_json_artifact(shap_metadata, "shap_metadata.json")

        # -------------------------
        # Log Extra Governance Artifacts
        # -------------------------
        if extra_artifacts:
            for name, content in extra_artifacts.items():

                # Case 1: file artifact (e.g. confusion_matrix.png)
                if isinstance(content, str) and os.path.exists(content):
                    mlflow.log_artifact(content)

                # Case 2: JSON-like object
                else:
                    _log_json_artifact(content, f"{name}.json")

        # -------------------------
        # Log Pipeline & Model
        # -------------------------
        mlflow.sklearn.log_model(
            pipeline,
            artifact_path="preprocessing_pipeline"
        )

        mlflow.sklearn.log_model(
            model,
            artifact_path="champion_model",
            registered_model_name="AutoML_Champion_Model"
        )

        print("[MLFLOW] Run successfully logged")


# =============================
# Helper Functions
# =============================
def _log_config_params(config: Dict[str, Any], prefix: str = "") -> None:
    """
    Recursively flatten & log config into MLflow parameters.
    """
    for key, value in config.items():
        name = f"{prefix}.{key}" if prefix else key

        if isinstance(value, dict):
            _log_config_params(value, name)
        elif isinstance(value, list):
            mlflow.log_param(name, ",".join(map(str, value)))
        else:
            mlflow.log_param(name, value)


def _sanitize_for_json(obj):
    """
    Recursively convert numpy & other non-JSON-safe objects
    into native Python types.
    """
    import numpy as np

    if isinstance(obj, dict):
        return {k: _sanitize_for_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sanitize_for_json(v) for v in obj]
    if isinstance(obj, tuple):
        return tuple(_sanitize_for_json(v) for v in obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)

    return obj


def _log_json_artifact(payload: Dict[str, Any], filename: str) -> None:
    """
    Persist dictionary as a JSON MLflow artifact.
    """
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, filename)
        with open(path, "w") as f:
            json.dump(_sanitize_for_json(payload), f, indent=2)

        mlflow.log_artifact(path)